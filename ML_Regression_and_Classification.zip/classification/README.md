# Classification Practical

This notebook follows the classification algorithms and workflow in the Machine Learning Algorithms Cheatsheet.

## Files
- `ML_Classification_CheatSheet.ipynb` — selectable classifiers, GridSearchCV, metrics, graphs, and optional PCA.
- `README.md` — setup, dataset changes, and viva questions.

## Run
Install packages if needed:

```bash
pip install pandas numpy matplotlib seaborn scikit-learn openpyxl
```

Open the notebook, change `file_path` to your local CSV/Excel path and set `target` to the exact label column. It does not download data.

## Select the classifier
Change `MODEL_NAME` in section 4 to one of:
- `Logistic Regression`
- `Decision Tree`
- `Gaussian Naive Bayes`
- `Multinomial Naive Bayes`
- `Bernoulli Naive Bayes`
- `KNN`
- `SVC`
- `Bagging`
- `Random Forest`
- `AdaBoost`
- `Gradient Boosting`

Each option has its own GridSearchCV parameter grid. Do not reuse parameters for a different estimator. The cheat sheet also lists XGBoost and Stacking; those need a separate model-specific setup, and XGBoost requires installing `xgboost`.

## Changing dataset/question
1. Change `file_path`.
2. Change `target = "Target"` to the exact target column.
3. Change or remove the `Record_ID` logic if the ID column is named differently.
4. Check `df.columns`, `df.dtypes`, missing values, and `y.value_counts()`.
5. If any class has fewer than five rows, reduce `n_splits` in `StratifiedKFold`.
6. If the target is continuous, use the regression notebook instead.

## PCA
The PCA section is optional. Use it only if the question asks for PCA. PCA is fitted within the pipeline and applied to numerical features after scaling.

## Viva questions
1. What is classification? Predicting a category or class.
2. How does classification differ from regression? Classification predicts labels; regression predicts continuous values.
3. What is Logistic Regression? A classifier that estimates class probabilities.
4. What is a Decision Tree? A model that splits data using feature-based rules.
5. What are Gini and entropy? Measures of class impurity used in decision trees.
6. What is Naive Bayes? A probabilistic classifier based on Bayes' theorem.
7. What is KNN? It predicts a class from nearby training observations.
8. What is SVC? Support Vector Classifier; kernels can model nonlinear boundaries.
9. What is Random Forest? An ensemble of decision trees.
10. What is Bagging? Combining models trained on sampled datasets.
11. What is boosting? Sequentially building models to improve earlier errors.
12. What is Stacking? Combining base-model predictions with a final estimator.
13. What is GridSearchCV? It searches parameter combinations using cross-validation.
14. Why tune hyperparameters? To choose settings with good validation performance.
15. What does C control in Logistic Regression/SVC? The regularization trade-off.
16. Why use StratifiedKFold? It approximately preserves class proportions in each fold.
17. Why use train/test split? To estimate performance on unseen data.
18. Why use a pipeline? It keeps preprocessing inside cross-validation training folds.
19. Why impute missing values? Most standard estimators cannot directly train with missing features.
20. Why encode categorical data? Most estimators require numerical inputs.
21. Why scale features? It helps scale-sensitive models such as KNN and SVC.
22. What is PCA? A transformation to components that capture variance.
23. Why scale before PCA? PCA can be affected by feature scales.
24. What is accuracy? The proportion of predictions that are correct.
25. What is precision? The proportion of predicted class positives that are correct.
26. What is recall? The proportion of actual class positives that are identified.
27. What is F1-score? The harmonic mean of precision and recall.
28. What does a confusion matrix show? Counts of actual versus predicted classes.
29. What is ROC-AUC? A measure of binary classifier ranking performance.
30. What is overfitting? Good training performance but poor performance on unseen data.
