# Machine Remaining Useful Life Regression

## 1. What this notebook does

This notebook compares two Support Vector Regression (SVR) models for predicting `Remaining_Useful_Life_Hours`:

1. **SVR without PCA**
2. **SVR with PCA**

It uses data cleaning, missing-value imputation, categorical encoding, scaling, hyperparameter tuning, five-fold evaluation, metrics, graphs, and a paired t-test.

The notebook reads a dataset stored on your computer. It does **not** download the dataset from the internet.

## 2. Requirements

Install these packages if they are not already available in your Jupyter environment:

```bash
pip install pandas numpy matplotlib seaborn scikit-learn scipy openpyxl
```

- `openpyxl` is used by pandas to read many `.xlsx` files.
- If your dataset is a CSV, you do not need `openpyxl`.

## 3. How to run it

1. Put the dataset in a folder on your computer.
2. Open `ML_Model_QP_CheatSheet.ipynb` in Jupyter Notebook or JupyterLab.
3. In the **Read the dataset** section, change `file_path` to your real file path.
4. Use `pd.read_csv()` for CSV files or `pd.read_excel()` for Excel files. The notebook selects the reader based on the file extension.
5. Run the notebook from the first cell to the last cell.
6. Read the printed metrics and graphs after execution.

Example Windows paths:

```python
file_path = r"C:\Users\YourName\Downloads\machine_rul.csv"
file_path = r"C:\Users\YourName\Downloads\machine_rul.xlsx"
```

The `r` before the path helps Windows backslashes work correctly.

## 4. If the question gives a different dataset

Check these items before running the notebook.

### A. Change the file path

```python
file_path = r"C:\path\to\your_dataset.csv"
```

Use the path and extension of the actual file.

### B. Change the target column

The current target is:

```python
target = "Remaining_Useful_Life_Hours"
```

If the question gives a different target, replace the text with the **exact column name** from `df.columns`.

For example, if the target column is `Maintenance_Cost`:

```python
target = "Maintenance_Cost"
```

### C. Remove the correct identifier column

The current code drops `Record_ID`:

```python
df.drop(columns=["Record_ID"], inplace=True)
```

If the new dataset has a unique identifier such as `Machine_ID`, change it to:

```python
df.drop(columns=["Machine_ID"], inplace=True)
```

If there is no identifier column, remove that line. Do not drop a useful predictor by mistake. The column name must match the dataset exactly; check `df.columns`.

### D. Check categorical and numerical columns

The notebook identifies numerical and categorical columns automatically:

```python
num_cols = X.select_dtypes(include="number").columns.tolist()
cat_cols = X.select_dtypes(exclude="number").columns.tolist()
```

Usually, this means you do not need to list every feature manually. If a column contains numbers that actually represent categories (for example, machine type coded as 1, 2, 3), convert it to a categorical/object type before creating `num_cols` and `cat_cols`.

Example:

```python
X["Machine_Type"] = X["Machine_Type"].astype("object")
```

Use the exact column name from your dataset.

### E. If the target is classification instead of regression

This notebook is a **regression** workflow. It predicts a continuous numerical value. Do not just change the target name if the new question asks for classes such as `Pass/Fail`, `Yes/No`, or machine `Failure/No Failure`.

For classification, you must change the estimator and evaluation metrics. For example, a classifier such as `SVC` or `RandomForestClassifier` can be used if it is included in the question/cheat sheet. Metrics may include accuracy, precision, recall, F1-score, and a confusion matrix. Follow the algorithm and metrics specified by the question.

### F. If the question asks for a different algorithm

The current pipeline uses:

```python
SVR(kernel="rbf")
```

If the question specifies another algorithm, replace the estimator and its hyperparameter grid with the ones for that algorithm. The parameter names in `GridSearchCV` must match the estimator's parameter names. For a pipeline step named `"svr"`, parameters use the prefix `svr__`, such as `svr__C`.

Do not use the SVR parameter grid unchanged for a different model.

### G. If the question does not ask for PCA

You can use only the no-PCA pipeline (`m1`) and omit the PCA model, explained-variance graph, and comparison parts if the question does not require them.

If the question asks for PCA, keep scaling before PCA and keep PCA inside the pipeline so it is fitted on training data during cross-validation.

### H. If the question changes the evaluation setup

The current notebook uses five outer folds and three inner folds for grid search:

```python
kf = KFold(n_splits=5, shuffle=True, random_state=42)
```

and:

```python
GridSearchCV(model, grid, cv=3, ...)
```

Change these only if the question specifies different folds or a different validation strategy. If comparing two models, use the same outer folds for both models.

## 5. Hyperparameter tuning in this notebook

The SVR grid is:

```python
grid = {
    "svr__C": [0.1, 1, 10, 100],
    "svr__gamma": ["scale", 0.01, 0.1],
    "svr__epsilon": [0.01, 0.1, 0.5]
}
```

- **`C`**: controls the penalty for errors and the regularization trade-off.
- **`gamma`**: controls the influence range of points for the RBF kernel.
- **`epsilon`**: sets the width of the error-insensitive region in SVR.

The grid is searched using `GridSearchCV` with three-fold inner cross-validation. The outer five-fold loop estimates performance on held-out folds.

## 6. Metrics used

- **RMSE**: gives larger errors more weight; lower is better.
- **MAE**: average absolute prediction error; lower is better.
- **R²**: indicates how much variation is explained relative to a mean-prediction baseline; higher is generally better.
- **MAPE**: average absolute percentage error; lower is better. It can be misleading if target values are zero or very close to zero.
- **Train-validation RMSE gap**: a large positive gap can indicate overfitting.
- **Paired t-test**: compares the fold-wise RMSE values for the two models. The notebook uses a two-sided test with significance level 0.05. A p-value below 0.05 is evidence of a difference in mean fold RMSE; it does not prove which model is practically better on its own.

## 7. Common errors

**`FileNotFoundError`**
- Check the spelling and full path.
- Make sure the file is on your computer and not just in a browser download list.

**`KeyError` for a column**
- Run `print(df.columns.tolist())`.
- Update the target or identifier name to exactly match the dataset, including spaces and underscores.

**`ModuleNotFoundError`**
- Install the missing package in the same Python environment used by Jupyter.

**Excel-reading error**
- Install `openpyxl` using `pip install openpyxl`.

**`ValueError` about missing values**
- Check whether the target column contains missing values. The notebook drops rows with a missing target; missing predictor values are imputed inside the pipelines.

**A graph or metric errors**
- Run cells in order and check that the dataset columns match the question.

## 8. Viva questions and short answers

1. **What is regression?**  
   Regression predicts a continuous numerical value.

2. **Why is this a regression problem?**  
   `Remaining_Useful_Life_Hours` is a numerical target.

3. **What is SVR?**  
   Support Vector Regression applies support-vector methods to predict numerical values.

4. **Why use the RBF kernel?**  
   It can model nonlinear relationships between predictors and the target.

5. **What is hyperparameter tuning?**  
   Searching for parameter settings that give better validation performance.

6. **What does `GridSearchCV` do?**  
   It evaluates combinations from a parameter grid using cross-validation and selects the best-scoring combination.

7. **What are `C`, `gamma`, and `epsilon` in SVR?**  
   `C` controls the penalty/regularization trade-off, `gamma` controls RBF influence, and `epsilon` defines the error-insensitive margin.

8. **Why scale numerical features?**  
   Features on very different scales can affect distance- and kernel-based methods unevenly.

9. **What is PCA?**  
   Principal Component Analysis transforms correlated numerical features into components that capture variance.

10. **Why apply scaling before PCA?**  
    PCA is affected by feature scale, so numerical features are standardized first.

11. **What does `PCA(n_components=0.95)` mean?**  
    It retains enough components to explain at least 95% of the variance in the numerical data passed to PCA.

12. **Why impute missing values?**  
    Many scikit-learn estimators cannot directly train on missing values.

13. **Why use `OneHotEncoder`?**  
    It converts categorical values into numeric indicator columns.

14. **What is data leakage?**  
    It occurs when information from validation/test data influences model fitting or preprocessing.

15. **Why use a pipeline?**  
    It keeps preprocessing and modelling together and allows preprocessing to be fitted within each training fold.

16. **Why use the same folds for both models?**  
    The comparison is fairer because both models are evaluated on the same held-out observations.

17. **What is RMSE?**  
    The square root of the mean squared prediction error; lower is better.

18. **What is MAE?**  
    The average absolute difference between actual and predicted values.

19. **What does R² measure?**  
    It compares model prediction error with the variation around the target mean. It can be negative when the model performs poorly.

20. **What is MAPE?**  
    Mean Absolute Percentage Error. It is problematic when actual target values are zero or near zero.

21. **What is the null hypothesis in the paired t-test?**  
    The mean difference between paired fold-wise RMSE values is zero.

22. **What does p < 0.05 mean here?**  
    Under the test assumptions, the observed fold-wise difference is statistically significant at the 5% level.

23. **Why remove an ID column?**  
    A unique identifier usually has no meaningful predictive relationship and can introduce noise.

24. **What is overfitting?**  
    When a model fits training data well but generalizes poorly to unseen data.

25. **How would you decide between the PCA and no-PCA models?**  
    Compare cross-validation metrics, variability, tuning time, and the paired test; consider the problem's requirements rather than choosing from one score alone.

## 9. Final practical checklist

- [ ] Set the correct local dataset path.
- [ ] Confirm the target and identifier column names.
- [ ] Check missing values, data types, and duplicates.
- [ ] Confirm numerical and categorical columns.
- [ ] Run every cell in order.
- [ ] Check that the hyperparameter search completes.
- [ ] Record the metrics, plots, best parameters, and paired t-test result.
- [ ] Explain why regression, SVR, PCA, and the selected metrics fit the question.
